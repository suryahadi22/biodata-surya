function portofolio() {
	document.getElementById('keren').innerHTML = `
		<div class="halo-keren">
			<h3>Portofolio Saya</h3>
			<li>Writter of <a class="hyperlink" href="https://jurnalismuda.com">JurnalisMuda.com</a></li>
			<li>Doing Project KONI Kab. Blitar</li>
			<li><a class="hyperlink" href="https://bloglink.id">BlogLink</a> Developer team</li>
		</div>
	`;
}

function cv() {
	document.getElementById('keren').innerHTML = `
		<div class="halo-keren">
			<h3>Curriculum Vitae</h3>
			<table border="1">
				<tr>
					<td>Tempat, Tanggal Lahir</td>
					<td>Tulungagung, 22 Maret 1999</td>
				</tr>
				<tr>
					<td>Status Perkawinan</td>
					<td>Belum Menikah</td>
				</tr>
				<tr>
					<td>Jenis Kelamin</td>
					<td>Laki-Laki</td>
				</tr>
				<tr>
					<td>Tinggi Badan</td>
					<td>165cm</td>
				</tr>
				<tr>
					<td>Agama</td>
					<td>Islam</td>
				</tr>
				<tr>
					<td>Alamat Asal</td>
					<td>RT 02 RW 01 Dusun Contong Ds. Bandung Kec. Bandung  Kab. Tulungagung – JATIM</td>
				</tr>
				<tr>
					<td>Alamat Tinggal</td>
					<td>Bintaro - Tangerang Selatan - Banten</td>
				</tr>
			</table>
		</div>
	`
}